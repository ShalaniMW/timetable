/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.timetablemanager.models;

/**
 *
 * @author Shelani Wijesekera
 */
public class Duration {

	public static final int THIRTY_MINUTES = 0;
	public static final int ONE_HOUR = 1;
}
