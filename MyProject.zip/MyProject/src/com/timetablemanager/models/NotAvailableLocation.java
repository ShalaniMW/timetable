/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.timetablemanager.models;

/**
 *
 * @author Shelani Wijesekera
 */
public class NotAvailableLocation {
    private String id;
    private String room;
     private int stime;
    private int etime;
    private String day;

    public NotAvailableLocation(String id, String room, int stime, int etime, String day) {
        this.id = id;
        this.room = room;
        this.stime = stime;
        this.etime = etime;
        this.day = day;
    }
   

   

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getRoom() {
        return room;
    }

    public void setRoom(String room) {
        this.room = room;
    }

    public String getDay() {
        return day;
    }

    public void setDay(String day) {
        this.day = day;
    }

    public int getsTime() {
        return stime;
    }

    public void setsTime(int stime) {
        this.stime = stime;
    }

    public int geteTime() {
        return etime;
    }

    public void seteTime(int etime) {
        this.etime = etime;
    }
    
    
    
}
