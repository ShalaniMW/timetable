/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.timetablemanager.controllers;

import com.timetablemanager.database.DatabaseHandler;
import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import static javafx.application.Application.launch;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.geometry.Pos;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ProgressIndicator;
import javafx.scene.image.Image;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.VBox;
import javafx.scene.text.Text;
import javafx.stage.Stage;
import listeners.OnTaskCompleteListener;

/**
 * FXML Controller class
 *
 * @author Shelani Wijesekera
 */
public class MainController implements Initializable,OnTaskCompleteListener {
    
    @FXML
	private Button btn_working_days;
    @FXML
	private AnchorPane controllerPane;
    @FXML
	private AnchorPane mainAnchorPane;
    @FXML
    private VBox progressDialogVBox;
    @FXML
	private Text successFailedText;

    /**
     * Initializes the controller class.
     */
    @Override
	public void initialize(URL arg0, ResourceBundle arg1)
	{
		 
		 
		 //connect to the database
		 
		 Runnable r = new Runnable() 
		 {
	         public void run()
	         {
	        	 //DatabaseHandler.makeConnection(MainController.this);
	         }
	     };
	     new Thread(r).start();
	  
	}
        @FXML
        void onWorkingDaysButtonClicked(ActionEvent event){
            
            try{
		
	FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("/com/timetablemanager/views/WorkingDayHour.fxml"));
            Parent root1 = (Parent) fxmlLoader.load();
            Stage stage = new Stage();
            stage.setScene(new Scene(root1));  
            stage.show();
            }catch(Exception e){
                System.out.println(e);
            }}
      

    @Override
    public void onFinished(boolean isSuccess) {
       
		
		/*if(isSuccess)
		{
			Image image = new Image(getClass().getResourceAsStream("success.png"));
//			File file = new File("src/views/success.png");
//		    Image image = new Image(file.toURI().toString());
		
			successFailedText.setText("Connected");
		
		}
		else
		{
			Image image = new Image(getClass().getResourceAsStream("failed.png"));
			successFailedText.setText("No Internet");
		}}*/

  
}}

