/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.timetablemanager.utils;

import java.sql.*;

/**
 *
 * @author Rajindu's PC
 */
public class ConnectionUtil {
    public static com.mysql.jdbc.Connection conn = null;
    public Connection getConnection(){
        Connection conn;
        try{
            conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/timetable_db", "root","shl199809");
            if(conn != null){System.out.println("connection success " );}
                
            return conn;
        }catch(Exception ex){
            System.out.println("Error: " + ex.getMessage());
            return null;
        }
    }
}
