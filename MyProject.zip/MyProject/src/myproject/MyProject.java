/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package myproject;



import com.timetablemanager.database.DatabaseHandler;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.application.Application;
import static javafx.application.Application.launch;
import javafx.event.EventHandler;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.layout.StackPane;
import javafx.stage.Stage;
import listeners.OnTaskCompleteListener;


/**
 *
 * @author Shelani Wijesekera
 */
public class MyProject extends Application {
    
    
    
    
   @Override
    public void start(Stage stage) throws Exception {
        Parent root = FXMLLoader.load(getClass().getResource("/com/timetablemanager/views/Dashboard.fxml"));
        stage.setResizable(false);
        Scene scene = new Scene(root);
        
        stage.setScene(scene);
        stage.show();
    }

    
     
    public static void main(String[] args) {
        launch(args);
    }
    
}
