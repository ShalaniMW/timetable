package listeners;

public interface OnTaskCompleteListener
{
	public void onFinished(boolean isSuccess);
}
